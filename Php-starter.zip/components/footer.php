<script src="./assets/js/bootstrap.bundle.min.js"></script>
<script src="./assets/js/aos.js"></script>
<script src="./assets/js/anime.min.js"></script>
<script src="./assets/js/wow.min.js"></script>
<script src="./assets/js/font.js"></script>
<script src="./assets/js/jquery-3.3.1.min.js"></script>
<script src="./assets/js/jquery.fancybox.min.js"></script>
<script src="./assets/js/owl.carousel.min.js"></script>
<script src="./assets/js/video.min.js"></script>
<script src="./assets/js/custom.js"></script>

</body>
</html>